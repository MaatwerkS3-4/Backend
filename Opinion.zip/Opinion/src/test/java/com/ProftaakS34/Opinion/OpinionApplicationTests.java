package com.ProftaakS34.Opinion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpinionApplicationTests {

	@Test
	void contextLoads() {
	}

}
